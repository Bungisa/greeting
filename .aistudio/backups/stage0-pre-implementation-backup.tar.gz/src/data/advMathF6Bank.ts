import type { ExtractedTextbookExerciseSeed } from './extractedTextbookExerciseBank.ts';
import { ADV_MATH_F6_PART1_TUPLES, type AdvMathF6Tuple } from './advMathF6Part1.ts';
import { ADV_MATH_F6_PART2_TUPLES } from './advMathF6Part2.ts';
import { ADV_MATH_F6_PART3_TUPLES } from './advMathF6Part3.ts';

const ADV_MATH_F6_TEXTBOOK_TITLE =
  "Mathematics for Advanced Secondary Schools - Student's Book Form Six (2025 Revised Edition)";

function buildAdvMathDistractors(correct: string, subTopic: string, idx: number): [string, string, string] {
  const c = correct.trim();

  // 1. Pure integer or decimal number
  if (/^-?\d+(\.\d+)?$/.test(c)) {
    const val = parseFloat(c);
    const decimals = c.includes('.') ? c.split('.')[1].length : 0;
    const step = decimals > 0 ? Math.max(Number((val * 0.12).toFixed(decimals)), Math.pow(10, -decimals)) : Math.max(1, Math.round(Math.abs(val) * 0.15));
    const d1 = (val + step).toFixed(decimals);
    const d2 = (val - step === val ? val + 2 * step : val - step).toFixed(decimals);
    const d3 = (val + 2 * step).toFixed(decimals);
    return [d1, d2, d3];
  }

  // 2. Simple fraction a/b
  const fracMatch = c.match(/^(-?\d+)\s*\/\s*(\d+)$/);
  if (fracMatch) {
    const num = parseInt(fracMatch[1], 10);
    const den = parseInt(fracMatch[2], 10);
    return [
      `${num + 1}/${den}`,
      `${Math.max(1, Math.abs(num - 1))}/${den + 1}`,
      `${num + 2}/${den + 2}`
    ];
  }

  // 3. Numbers embedded inside expressions or multi-part answers
  const numberMatches = Array.from(c.matchAll(/(-?\d+(?:\.\d+)?)/g));
  if (numberMatches.length > 0) {
    const mutateNumbers = (delta: number, factor: number): string => {
      let count = 0;
      return c.replace(/(-?\d+(?:\.\d+)?)/g, (m) => {
        count++;
        if (count > 3) return m;
        const n = parseFloat(m);
        if (n === 0 || n === 1 || n === 2) {
          return String(n + delta);
        }
        if (m.includes('.')) {
          const dec = m.split('.')[1].length;
          return (n * factor + delta * Math.pow(10, -dec)).toFixed(dec);
        }
        return String(Math.round(n * factor + delta));
      });
    };
    const cand1 = mutateNumbers(1, 1);
    const cand2 = mutateNumbers(-1, 1);
    const cand3 = mutateNumbers(2, 1.1);
    if (cand1 !== c && cand2 !== c && cand3 !== c && cand1 !== cand2) {
      return [cand1, cand2, cand3];
    }
  }

  // 4. Sign / trig-hyperbolic / operator variations for symbolic proofs and identities
  const signFlip1 = c.includes('+') ? c.replace('+', '−') : c.includes('−') ? c.replace('−', '+') : `${c} + 1`;
  const signFlip2 = c.includes('cosh')
    ? c.replace(/cosh/g, 'sinh')
    : c.includes('cos')
      ? c.replace(/cos/g, 'sin')
      : `${c} (with opposite sign)`;
  const fallback3 = `2 × (${c})`;

  const unique = Array.from(new Set([signFlip1, signFlip2, fallback3, `${c} − 1`, `Half of (${c}) (${subTopic} #${idx + 1})`])).filter(
    (d) => d !== c
  );
  return [unique[0] || `${c} (Option A)`, unique[1] || `${c} (Option B)`, unique[2] || `${c} (Option C)`];
}

function convertTupleToSeed(tuple: AdvMathF6Tuple, idx: number): ExtractedTextbookExerciseSeed {
  const [topic, subTopic, exerciseRef, rawQuestion, correctAnswer, explanation] = tuple;
  const cleanQuestion = rawQuestion.replace(/\[cite[^\]]*\]/gi, '').trim();
  const cleanAnswer = correctAnswer.replace(/\[cite[^\]]*\]/gi, '').trim();
  const cleanExplanation = explanation.replace(/\[cite[^\]]*\]/gi, '').trim();

  const [d1, d2, d3] = buildAdvMathDistractors(cleanAnswer, subTopic, idx);
  const correctIndex = (idx % 4) as 0 | 1 | 2 | 3;
  const options: [string, string, string, string] = ['', '', '', ''];
  options[correctIndex] = cleanAnswer;
  const distractors = [d1, d2, d3];
  let dIdx = 0;
  for (let i = 0; i < 4; i++) {
    if (i !== correctIndex) {
      options[i] = distractors[dIdx++];
    }
  }

  const isRevision = /revision/i.test(exerciseRef);
  const isProject = /project/i.test(exerciseRef);
  const difficulty: 'easy' | 'medium' | 'hard' = isRevision || isProject ? 'hard' : idx % 3 === 0 ? 'medium' : 'hard';

  return {
    id: `tie-f6-advmath-${idx + 1}`,
    cls: 'Form 6',
    subject: 'Advanced Mathematics',
    textbookTitle: ADV_MATH_F6_TEXTBOOK_TITLE,
    topic,
    subTopic: `${subTopic} (${exerciseRef})`,
    exerciseRef,
    question: `[${exerciseRef}] ${cleanQuestion}`,
    options,
    correctIndex,
    explanation: cleanExplanation,
    hint: cleanExplanation,
    isMultipleChoice: false
  };
}

const ALL_ADV_MATH_F6_TUPLES: AdvMathF6Tuple[] = [
  ...ADV_MATH_F6_PART1_TUPLES,
  ...ADV_MATH_F6_PART2_TUPLES,
  ...ADV_MATH_F6_PART3_TUPLES
];

export const ADV_MATH_F6_BANK: ExtractedTextbookExerciseSeed[] = ALL_ADV_MATH_F6_TUPLES.map((tuple, idx) =>
  convertTupleToSeed(tuple, idx)
);

// ============================================================================
// CHAPTER SVG DIAGRAMS FROM ATTACHED FORM 6 ADVANCED MATHEMATICS HTML FILES
// ============================================================================

const SVG_CH1_CONIC_AND_TOWER = `<svg viewBox="0 0 760 250" width="100%" height="230" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-c1" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155"/>
    </marker>
  </defs>
  <text x="125" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Parabola y² = 4ax</text>
  <line x1="20" y1="125" x2="230" y2="125" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c1)"/>
  <line x1="90" y1="225" x2="90" y2="30" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c1)"/>
  <line x1="50" y1="35" x2="50" y2="215" stroke="#dc2626" stroke-width="1.5" stroke-dasharray="5,4"/>
  <text x="45" y="45" font-size="10" fill="#dc2626" text-anchor="end">x = −a</text>
  <path d="M 210 40 Q 90 125 210 210" fill="none" stroke="#2563eb" stroke-width="2.5"/>
  <circle cx="130" cy="125" r="3.5" fill="#dc2626"/>
  <text x="130" y="142" font-size="10" font-weight="bold" fill="#dc2626" text-anchor="middle">F(a, 0)</text>

  <text x="380" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Ellipse x²/a² + y²/b² = 1</text>
  <line x1="260" y1="125" x2="500" y2="125" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c1)"/>
  <line x1="380" y1="225" x2="380" y2="30" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c1)"/>
  <ellipse cx="380" cy="125" rx="85" ry="52" fill="none" stroke="#059669" stroke-width="2.5"/>
  <circle cx="320" cy="125" r="3" fill="#dc2626"/>
  <circle cx="440" cy="125" r="3" fill="#dc2626"/>
  <text x="320" y="140" font-size="9" fill="#dc2626" text-anchor="middle">F'(−ae,0)</text>
  <text x="440" y="140" font-size="9" fill="#dc2626" text-anchor="middle">F(ae,0)</text>

  <text x="635" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Cooling Tower (Rev Ex 1 Q30)</text>
  <line x1="535" y1="135" x2="735" y2="135" stroke="#64748b" stroke-width="1.2" stroke-dasharray="4,3"/>
  <line x1="635" y1="225" x2="635" y2="30" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c1)"/>
  <ellipse cx="635" cy="55" rx="42" ry="9" fill="#e0f2fe" stroke="#0284c7" stroke-width="1.8"/>
  <path d="M 565 210 C 602 155, 602 105, 593 55" fill="none" stroke="#0284c7" stroke-width="2.5"/>
  <path d="M 705 210 C 668 155, 668 105, 677 55" fill="none" stroke="#0284c7" stroke-width="2.5"/>
  <ellipse cx="635" cy="210" rx="70" ry="12" fill="none" stroke="#0284c7" stroke-width="2"/>
  <text x="635" y="130" font-size="10" font-weight="bold" fill="#dc2626" text-anchor="middle">Min Ø = 160 m</text>
  <text x="635" y="236" font-size="10" fill="#1e293b" text-anchor="middle">h₁ = 80 m, h₂ = 60 m</text>
</svg>`;

const SVG_CH2_VECTORS = `<svg viewBox="0 0 760 240" width="100%" height="220" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-v2" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#1e293b"/>
    </marker>
    <marker id="arr-vblue" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#2563eb"/>
    </marker>
  </defs>
  <text x="130" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">3D Vector OP (Fig 2.2)</text>
  <line x1="110" y1="145" x2="110" y2="35" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-v2)"/>
  <line x1="110" y1="145" x2="225" y2="145" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-v2)"/>
  <line x1="110" y1="145" x2="40" y2="210" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-v2)"/>
  <line x1="110" y1="145" x2="195" y2="65" stroke="#2563eb" stroke-width="2.5" marker-end="url(#arr-vblue)"/>
  <circle cx="195" cy="65" r="3.5" fill="#dc2626"/>
  <text x="200" y="60" font-size="10" font-weight="bold" fill="#dc2626">P(x, y, z)</text>
  <text x="32" y="220" font-size="10" fill="#334155">x</text>
  <text x="232" y="148" font-size="10" fill="#334155">y</text>
  <text x="110" y="28" font-size="10" fill="#334155">z</text>

  <text x="385" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Ratio Theorem r = (λb + μa)/(λ + μ)</text>
  <line x1="300" y1="195" x2="330" y2="65" stroke="#2563eb" stroke-width="2" marker-end="url(#arr-vblue)"/>
  <line x1="300" y1="195" x2="465" y2="120" stroke="#2563eb" stroke-width="2" marker-end="url(#arr-vblue)"/>
  <line x1="330" y1="65" x2="465" y2="120" stroke="#0f172a" stroke-width="2"/>
  <line x1="300" y1="195" x2="395" y2="91" stroke="#dc2626" stroke-width="2.2" marker-end="url(#arr-v2)"/>
  <text x="290" y="208" font-size="11" font-weight="bold" fill="#0f172a">O</text>
  <text x="325" y="55" font-size="11" font-weight="bold" fill="#0f172a">A(a)</text>
  <text x="475" y="122" font-size="11" font-weight="bold" fill="#0f172a">B(b)</text>
  <text x="402" y="84" font-size="11" font-weight="bold" fill="#dc2626">P(r)</text>
  <text x="360" y="72" font-size="10" fill="#059669">λ</text>
  <text x="432" y="102" font-size="10" fill="#059669">μ</text>

  <text x="635" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Projection of a onto b (Fig 2.10)</text>
  <line x1="535" y1="175" x2="730" y2="175" stroke="#059669" stroke-width="2.5" marker-end="url(#arr-v2)"/>
  <line x1="535" y1="175" x2="655" y2="75" stroke="#2563eb" stroke-width="2.5" marker-end="url(#arr-vblue)"/>
  <line x1="655" y1="75" x2="655" y2="175" stroke="#dc2626" stroke-width="1.5" stroke-dasharray="5,4"/>
  <rect x="645" y="165" width="10" height="10" fill="none" stroke="#dc2626" stroke-width="1.2"/>
  <text x="585" y="115" font-size="11" font-weight="bold" fill="#2563eb">a</text>
  <text x="715" y="192" font-size="11" font-weight="bold" fill="#059669">b</text>
  <text x="572" y="165" font-size="11" fill="#0f172a">θ</text>
  <text x="595" y="195" font-size="10" font-weight="bold" fill="#dc2626">Proj_b(a) = (a·b/|b|²)b</text>
</svg>`;

const SVG_CH3_HYPERBOLIC = `<svg viewBox="0 0 740 240" width="100%" height="220" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-h3" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155"/>
    </marker>
  </defs>
  <text x="200" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Graphs of y = cosh x and y = sinh x (Figs 3.1 &amp; 3.2)</text>
  <line x1="35" y1="145" x2="365" y2="145" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-h3)"/>
  <line x1="200" y1="225" x2="200" y2="30" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-h3)"/>
  <path d="M 65 40 Q 200 185 335 40" fill="none" stroke="#2563eb" stroke-width="2.5"/>
  <path d="M 75 215 C 155 185, 245 105, 325 35" fill="none" stroke="#dc2626" stroke-width="2.5"/>
  <circle cx="200" cy="112" r="3.5" fill="#2563eb"/>
  <text x="224" y="114" font-size="10" font-weight="bold" fill="#2563eb">(0, 1)</text>
  <text x="315" y="65" font-size="11" font-weight="bold" fill="#2563eb">y = cosh x</text>
  <text x="295" y="105" font-size="11" font-weight="bold" fill="#dc2626">y = sinh x</text>

  <text x="565" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Bounded Region (Ex 3.7 Q10)</text>
  <line x1="415" y1="190" x2="715" y2="190" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-h3)"/>
  <line x1="565" y1="220" x2="565" y2="30" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-h3)"/>
  <path d="M 455 75 Q 565 205 675 75 Z" fill="#bfdbfe" fill-opacity="0.65" stroke="#1d4ed8" stroke-width="2.2"/>
  <line x1="435" y1="75" x2="695" y2="75" stroke="#dc2626" stroke-width="1.8" stroke-dasharray="5,4"/>
  <text x="685" y="68" font-size="10" font-weight="bold" fill="#dc2626">y = b</text>
  <text x="565" y="125" font-size="11" font-weight="bold" fill="#1e3a8a" text-anchor="middle">y = a cosh(x/a)</text>
  <text x="582" y="155" font-size="10" font-weight="bold" fill="#0f172a">(0, a)</text>
</svg>`;

const SVG_CH5_PROB_AND_NORMAL = `<svg viewBox="0 0 740 230" width="100%" height="215" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-p5" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155"/>
    </marker>
  </defs>
  <text x="175" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Venn Diagram of Events A &amp; B (Figs 5.3 &amp; 5.4)</text>
  <rect x="30" y="35" width="290" height="170" rx="6" fill="#f8fafc" stroke="#475569" stroke-width="1.5"/>
  <text x="42" y="52" font-size="11" font-weight="bold" fill="#334155">S</text>
  <circle cx="140" cy="120" r="52" fill="#93c5fd" fill-opacity="0.55" stroke="#2563eb" stroke-width="2"/>
  <circle cx="205" cy="120" r="52" fill="#fca5a5" fill-opacity="0.55" stroke="#dc2626" stroke-width="2"/>
  <text x="112" y="124" font-size="11" font-weight="bold" fill="#1e3a8a">A ∩ B'</text>
  <text x="172" y="124" font-size="11" font-weight="bold" fill="#581c87" text-anchor="middle">A ∩ B</text>
  <text x="232" y="124" font-size="11" font-weight="bold" fill="#991b1b">A' ∩ B</text>

  <text x="540" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Standard Normal Curve Z ~ N(0, 1) (Fig 5.7)</text>
  <path d="M 540 185 L 540 52 C 575 52, 595 110, 625 155 L 625 185 Z" fill="#bfdbfe" fill-opacity="0.75"/>
  <line x1="360" y1="185" x2="720" y2="185" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-p5)"/>
  <line x1="540" y1="205" x2="540" y2="32" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-p5)"/>
  <path d="M 370 183 C 445 182, 485 52, 540 52 C 595 52, 635 182, 710 183" fill="none" stroke="#1d4ed8" stroke-width="2.5"/>
  <line x1="625" y1="155" x2="625" y2="185" stroke="#dc2626" stroke-width="1.8" stroke-dasharray="4,3"/>
  <text x="540" y="202" font-size="10" font-weight="bold" fill="#0f172a" text-anchor="middle">0 (μ)</text>
  <text x="625" y="202" font-size="10" font-weight="bold" fill="#dc2626" text-anchor="middle">z₁</text>
  <text x="582" y="140" font-size="10" font-weight="bold" fill="#1e3a8a" text-anchor="middle">P(0 ≤ Z ≤ z₁)</text>
</svg>`;

const SVG_CH6_COMPLEX = `<svg viewBox="0 0 740 235" width="100%" height="220" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-c6" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155"/>
    </marker>
  </defs>
  <text x="180" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Argand Diagram in Polar Form (Fig 6.4)</text>
  <line x1="35" y1="175" x2="325" y2="175" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c6)"/>
  <line x1="95" y1="215" x2="95" y2="35" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c6)"/>
  <line x1="95" y1="175" x2="255" y2="65" stroke="#2563eb" stroke-width="2.5" marker-end="url(#arr-c6)"/>
  <line x1="255" y1="65" x2="255" y2="175" stroke="#dc2626" stroke-width="1.5" stroke-dasharray="5,4"/>
  <text x="260" y="58" font-size="11" font-weight="bold" fill="#1e3a8a">P(x, y) = r(cos θ + i sin θ)</text>
  <text x="160" y="108" font-size="11" font-weight="bold" fill="#2563eb">r = |z|</text>
  <text x="265" y="125" font-size="10" font-weight="bold" fill="#dc2626">y = r sin θ</text>
  <text x="175" y="192" font-size="10" font-weight="bold" fill="#059669">x = r cos θ</text>
  <text x="135" y="166" font-size="11" fill="#0f172a">θ</text>

  <text x="555" y="22" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Circular Locus |z + 2 − i| = 5</text>
  <line x1="410" y1="135" x2="710" y2="135" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c6)"/>
  <line x1="585" y1="220" x2="585" y2="35" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-c6)"/>
  <circle cx="535" cy="110" r="68" fill="#dbeafe" fill-opacity="0.45" stroke="#2563eb" stroke-width="2.2"/>
  <circle cx="535" cy="110" r="3.5" fill="#dc2626"/>
  <line x1="535" y1="110" x2="592" y2="73" stroke="#dc2626" stroke-width="1.8"/>
  <text x="525" y="125" font-size="10" font-weight="bold" fill="#dc2626" text-anchor="end">C(−2, 1)</text>
  <text x="568" y="85" font-size="10" font-weight="bold" fill="#dc2626">r = 5</text>
</svg>`;

const SVG_CH7_ODE_APPS = `<svg viewBox="0 0 760 235" width="100%" height="220" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-o7" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#dc2626"/>
    </marker>
    <marker id="arr-g7" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#059669"/>
    </marker>
  </defs>
  <text x="120" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Falling Body (Fig 7.1)</text>
  <circle cx="120" cy="115" r="24" fill="#cbd5e1" stroke="#334155" stroke-width="2"/>
  <text x="120" y="119" font-size="11" font-weight="bold" text-anchor="middle" fill="#0f172a">m</text>
  <line x1="120" y1="91" x2="120" y2="42" stroke="#dc2626" stroke-width="2.2" marker-end="url(#arr-o7)"/>
  <text x="128" y="58" font-size="10" font-weight="bold" fill="#dc2626">F_d = kv</text>
  <line x1="120" y1="139" x2="120" y2="195" stroke="#059669" stroke-width="2.2" marker-end="url(#arr-g7)"/>
  <text x="128" y="182" font-size="10" font-weight="bold" fill="#059669">W = mg</text>

  <text x="365" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Damped Spring (Figs 7.2 &amp; 7.3)</text>
  <line x1="305" y1="35" x2="425" y2="35" stroke="#334155" stroke-width="3"/>
  <polyline points="365,35 365,50 350,58 380,70 350,82 380,94 350,106 365,114 365,130" fill="none" stroke="#2563eb" stroke-width="2.2"/>
  <rect x="335" y="130" width="60" height="42" rx="4" fill="#bfdbfe" stroke="#1d4ed8" stroke-width="2"/>
  <text x="365" y="155" font-size="11" font-weight="bold" text-anchor="middle" fill="#1e3a8a">m</text>
  <text x="365" y="205" font-size="10" font-weight="bold" fill="#0f172a" text-anchor="middle">mx'' + cx' + kx = F(t)</text>

  <text x="615" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Series RLC Circuit (Fig 7.4)</text>
  <rect x="500" y="55" width="225" height="125" fill="none" stroke="#334155" stroke-width="2"/>
  <rect x="535" y="47" width="45" height="16" fill="#fef08a" stroke="#ca8a04" stroke-width="1.5"/>
  <text x="557" y="42" font-size="10" font-weight="bold" text-anchor="middle" fill="#854d0e">R</text>
  <rect x="615" y="47" width="55" height="16" fill="#bbf7d0" stroke="#16a34a" stroke-width="1.5"/>
  <text x="642" y="42" font-size="10" font-weight="bold" text-anchor="middle" fill="#166534">L</text>
  <line x1="715" y1="108" x2="735" y2="108" stroke="#2563eb" stroke-width="2.5"/>
  <line x1="715" y1="120" x2="735" y2="120" stroke="#2563eb" stroke-width="2.5"/>
  <text x="745" y="118" font-size="10" font-weight="bold" fill="#1d4ed8">C</text>
  <circle cx="500" cy="115" r="14" fill="#ffffff" stroke="#dc2626" stroke-width="2"/>
  <text x="500" y="119" font-size="9" font-weight="bold" text-anchor="middle" fill="#dc2626">E(t)</text>
  <text x="612" y="205" font-size="10" font-weight="bold" fill="#0f172a" text-anchor="middle">Lq'' + Rq' + q/C = E(t)</text>
</svg>`;

const SVG_CH8_NUMERICAL = `<svg viewBox="0 0 760 235" width="100%" height="220" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px">
  <defs>
    <marker id="arr-n8" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155"/>
    </marker>
  </defs>
  <text x="135" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Newton-Raphson (Fig 8.1)</text>
  <line x1="25" y1="185" x2="245" y2="185" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-n8)"/>
  <line x1="45" y1="210" x2="45" y2="35" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-n8)"/>
  <path d="M 55 205 Q 135 165 215 45" fill="none" stroke="#2563eb" stroke-width="2.5"/>
  <line x1="195" y1="76" x2="115" y2="185" stroke="#dc2626" stroke-width="1.8"/>
  <line x1="195" y1="76" x2="195" y2="185" stroke="#64748b" stroke-width="1.2" stroke-dasharray="4,3"/>
  <circle cx="195" cy="76" r="3.5" fill="#dc2626"/>
  <text x="195" y="200" font-size="10" font-weight="bold" fill="#0f172a" text-anchor="middle">x_n</text>
  <text x="115" y="200" font-size="10" font-weight="bold" fill="#dc2626" text-anchor="middle">x_{n+1}</text>

  <text x="385" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Trapezium &amp; Simpson Strips (Figs 8.3–8.4)</text>
  <line x1="270" y1="185" x2="505" y2="185" stroke="#334155" stroke-width="1.5" marker-end="url(#arr-n8)"/>
  <path d="M 290 185 L 290 135 C 350 65, 420 55, 480 110 L 480 185 Z" fill="#dbeafe" fill-opacity="0.65"/>
  <path d="M 290 135 C 350 65, 420 55, 480 110" fill="none" stroke="#1d4ed8" stroke-width="2.5"/>
  <line x1="290" y1="135" x2="290" y2="185" stroke="#1e3a8a" stroke-width="1.5"/>
  <line x1="337" y1="95" x2="337" y2="185" stroke="#1e3a8a" stroke-width="1.2" stroke-dasharray="4,3"/>
  <line x1="385" y1="75" x2="385" y2="185" stroke="#1e3a8a" stroke-width="1.2" stroke-dasharray="4,3"/>
  <line x1="432" y1="82" x2="432" y2="185" stroke="#1e3a8a" stroke-width="1.2" stroke-dasharray="4,3"/>
  <line x1="480" y1="110" x2="480" y2="185" stroke="#1e3a8a" stroke-width="1.5"/>
  <text x="290" y="200" font-size="9" fill="#0f172a" text-anchor="middle">x₀</text>
  <text x="337" y="200" font-size="9" fill="#0f172a" text-anchor="middle">x₁</text>
  <text x="385" y="200" font-size="9" fill="#0f172a" text-anchor="middle">x₂</text>
  <text x="432" y="200" font-size="9" fill="#0f172a" text-anchor="middle">x₃</text>
  <text x="480" y="200" font-size="9" fill="#0f172a" text-anchor="middle">x₄</text>

  <text x="635" y="20" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f172a">Tent Roof Cross-Section (Ex 8.33)</text>
  <path d="M 535 185 L 535 145 Q 635 45 735 145 L 735 185 Z" fill="#dcfce7" stroke="#15803d" stroke-width="2"/>
  <line x1="585" y1="108" x2="585" y2="185" stroke="#15803d" stroke-width="1.2" stroke-dasharray="3,3"/>
  <line x1="635" y1="95" x2="635" y2="185" stroke="#dc2626" stroke-width="1.5" stroke-dasharray="4,3"/>
  <line x1="685" y1="108" x2="685" y2="185" stroke="#15803d" stroke-width="1.2" stroke-dasharray="3,3"/>
  <text x="635" y="202" font-size="10" font-weight="bold" fill="#0f172a" text-anchor="middle">Span = 8 m (h = 1 m)</text>
</svg>`;

export function getAdvMathF6DiagramSvg(
  questionText: string,
  topic?: string,
  subTopic?: string
): { title: string; svgHtml: string; caption?: string } | null {
  const combined = `${questionText} ${topic || ''} ${subTopic || ''}`.toLowerCase();

  // Chapter 1 diagrams
  if (
    combined.includes('cooling tower') ||
    combined.includes('revision exercise 1 q30') ||
    (combined.includes('coordinate geometry ii') &&
      (combined.includes('figure') || combined.includes('latus rectum') || combined.includes('foci')))
  ) {
    return {
      title: 'Chapter 1: Conic Sections & Hyperbolic Cooling Tower',
      caption: 'Standard Parabola y² = 4ax, Ellipse x²/a² + y²/b² = 1, and Hyperbolic Cooling Tower (Rev Ex 1 Q30)',
      svgHtml: SVG_CH1_CONIC_AND_TOWER
    };
  }

  // Chapter 2 diagrams
  if (
    combined.includes('figure 2.2') ||
    combined.includes('fig 2.2') ||
    combined.includes('figure 2.8') ||
    combined.includes('fig 2.8') ||
    combined.includes('figure 2.10') ||
    combined.includes('fig 2.10') ||
    (combined.includes('chapter 2: vectors') &&
      (combined.includes('projection') || combined.includes('ratio theorem')))
  ) {
    return {
      title: 'Chapter 2: 3D Vector, Ratio Theorem & Vector Projection',
      caption: 'Figures 2.2, 2.8 & 2.10 — 3D Position Vector OP, Ratio Theorem, and Orthogonal Projection of a onto b',
      svgHtml: SVG_CH2_VECTORS
    };
  }

  // Chapter 3 diagrams
  if (
    combined.includes('figures 3.1') ||
    combined.includes('fig 3.1') ||
    combined.includes('exercise 3.7 q10') ||
    (combined.includes('hyperbolic functions') &&
      (combined.includes('bounded region') || combined.includes('sketch the graphs')))
  ) {
    return {
      title: 'Chapter 3: Hyperbolic Functions y = cosh x, y = sinh x & Bounded Area',
      caption: 'Figures 3.1 & 3.2 and Exercise 3.7 Q10 Bounded Region between y = a cosh(x/a) and y = b',
      svgHtml: SVG_CH3_HYPERBOLIC
    };
  }

  // Chapter 5 diagrams
  if (
    combined.includes('figures 5.3') ||
    combined.includes('figure 5.7') ||
    (combined.includes('chapter 5: probability') &&
      (combined.includes('venn diagram') || combined.includes('z ~ n(0, 1)')))
  ) {
    return {
      title: 'Chapter 5: Venn Diagram of Events & Standard Normal Curve Z ~ N(0, 1)',
      caption: 'Figures 5.3, 5.4 & 5.7 — Probability of Combined Events and Standard Normal Distribution Area',
      svgHtml: SVG_CH5_PROB_AND_NORMAL
    };
  }

  // Chapter 6 diagrams
  if (
    combined.includes('figure 6.4') ||
    combined.includes('argand diagram') ||
    combined.includes('circular locus') ||
    combined.includes('|z + 2 − i| = 5')
  ) {
    return {
      title: 'Chapter 6: Argand Diagram in Polar Form & Circular Locus',
      caption: 'Figure 6.4 Polar Representation z = r(cos θ + i sin θ) and Circular Locus |z + 2 − i| = 5',
      svgHtml: SVG_CH6_COMPLEX
    };
  }

  // Chapter 7 diagrams
  if (
    combined.includes('figure 7.1') ||
    combined.includes('figures 7.2') ||
    combined.includes('figure 7.4') ||
    combined.includes('falling body') ||
    combined.includes('vibrating spring') ||
    combined.includes('rlc circuit')
  ) {
    return {
      title: 'Chapter 7: Differential Equation Physical Models',
      caption: 'Figures 7.1–7.4 — Falling Body with Air Resistance, Damped Vibrating Spring & Series RLC Circuit',
      svgHtml: SVG_CH7_ODE_APPS
    };
  }

  // Chapter 8 diagrams
  if (
    combined.includes('figure 8.1') ||
    combined.includes('figure 8.3') ||
    combined.includes('figure 8.4') ||
    combined.includes('tent roof') ||
    combined.includes('example 8.33') ||
    (combined.includes('numerical methods') &&
      (combined.includes('geometric derivation') || combined.includes('parabolic strips')))
  ) {
    return {
      title: 'Chapter 8: Newton-Raphson Tangent, Trapezium/Simpson Strips & Tent Roof',
      caption: 'Figures 8.1, 8.3, 8.4 & Example 8.33 — Numerical Root-Finding and Quadrature Strips',
      svgHtml: SVG_CH8_NUMERICAL
    };
  }

  return null;
}
